*Homepage*

#SNMP binaries and documentation are available at http://sharpsnmplib.codeplex.com

#SNMP source code is available at http://github.com/lextm/sharpsnmplib
 
*License*
Please read the following article to get the details,

KB 600012 Source code license explained
http://sharpsnmplib.codeplex.com/wikipage?title=600012&referringTitle=KB

*Samples*
All samples are provided in source code only. Please check out source code and find them.

*Build From Source Code*
From our KB http://sharpsnmplib.codeplex.com/wikipage?title=Knowledge%20Base you can find three articles,

KB 600005 How to compile source code on Windows
http://sharpsnmplib.codeplex.com/wikipage?title=600005&referringTitle=KB

KB 600006 How to compile source code on openSUSE
http://sharpsnmplib.codeplex.com/wikipage?title=600006&referringTitle=KB

KB 600007 How to compile source code on Ubuntu 10.10
http://sharpsnmplib.codeplex.com/wikipage?title=600007&referringTitle=KB

*Notes*
1. VB.NET projects cannot be compiled under Mono at this moment.
2. WinForms applications are not recommended to be used in Visual Studio 2008. Please switch to Visual Studio 2010.